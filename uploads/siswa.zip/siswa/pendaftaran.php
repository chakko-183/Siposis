<?php
session_start();
// Simulasi data siswa yang login
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = [
        'nama' => 'sarep bin joso',
        'kelas' => '11 IPA 2',
        'nisn' => '1234567890'
    ];
}

$user = $_SESSION['user'];
$success_message = '';
$error_message = '';

if ($_POST) {
    // Proses form pendaftaran
    $jabatan = $_POST['jabatan'] ?? '';
    $visi = $_POST['visi'] ?? '';
    $misi = $_POST['misi'] ?? '';
    $pengalaman = $_POST['pengalaman'] ?? '';
    
    if ($jabatan && $visi && $misi) {
        $success_message = "Pendaftaran berhasil disimpan!";
        // Di sini biasanya data disimpan ke database
    } else {
        $error_message = "Semua field wajib diisi!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIPOSIS - Pendaftaran</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: center;
            color: white;
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 30px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .user-info {
            text-align: center;
            color: white;
            margin-bottom: 40px;
            padding: 0 20px;
        }

        .user-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }

        .user-name {
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .user-title {
            opacity: 0.8;
            font-size: 0.9rem;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 5px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: #fff;
        }

        .nav-icon {
            margin-right: 12px;
            font-size: 1.2rem;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;
        }

        .form-container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        .form-title {
            font-size: 2rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-control-textarea {
            min-height: 100px;
            resize: vertical;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s ease;
            width: 100%;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .row {
            display: flex;
            gap: 20px;
        }

        .col-md-6 {
            flex: 1;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .row {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="user-info">
            <div class="user-avatar">👨‍🎓</div>
            <div class="user-name"><?= htmlspecialchars($user['nama']) ?></div>
            <div class="user-title">Dashboard Siswa</div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">📊</span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="pendaftaran.php" class="nav-link active">
                    <span class="nav-icon">📝</span>
                    Pendaftaran
                </a>
            </li>
            <li class="nav-item">
                <a href="upload.php" class="nav-link">
                    <span class="nav-icon">📤</span>
                    Upload Dokumen
                </a>
            </li>
            <li class="nav-item">
                <a href="status.php" class="nav-link">
                    <span class="nav-icon">ℹ️</span>
                    Status & Hasil
                </a>
            </li>
            <li class="nav-item">
                <a href="profil.php" class="nav-link">
                    <span class="nav-icon">👤</span>
                    Profil
                </a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="form-container">
            <h2 class="form-title">Formulir Pendaftaran OSIS</h2>
            
            <?php if ($success_message): ?>
                <div class="alert alert-success"><?= $success_message ?></div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="alert alert-error"><?= $error_message ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($user['nama']) ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Kelas</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($user['kelas']) ?>" readonly>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Jabatan yang Dilamar *</label>
                    <select name="jabatan" class="form-control" required>
                        <option value="">Pilih Jabatan</option>
                        <option value="ketua">Ketua OSIS</option>
                        <option value="wakil_ketua">Wakil Ketua OSIS</option>
                        <option value="sekretaris">Sekretaris</option>
                        <option value="bendahara">Bendahara</option>
                        <option value="sie_pendidikan">Sie Pendidikan & Pelatihan</option>
                        <option value="sie_kesenian">Sie Kesenian & Budaya</option>
                        <option value="sie_olahraga">Sie Olahraga & Kesehatan</option>
                        <option value="sie_sosial">Sie Sosial & Kemasyarakatan</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Visi *</label>
                    <textarea name="visi" class="form-control form-control-textarea" placeholder="Tuliskan visi Anda jika terpilih sebagai pengurus OSIS..." required></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Misi *</label>
                    <textarea name="misi" class="form-control form-control-textarea" placeholder="Tuliskan misi dan program kerja yang akan Anda laksanakan..." required></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Pengalaman Organisasi</label>
                    <textarea name="pengalaman" class="form-control form-control-textarea" placeholder="Ceritakan pengalaman organisasi yang pernah Anda ikuti..."></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Motivasi</label>
                    <textarea name="motivasi" class="form-control form-control-textarea" placeholder="Mengapa Anda ingin bergabung dengan OSIS?"></textarea>
                </div>

                <button type="submit" class="btn">Simpan Pendaftaran</button>
            </form>
        </div>
    </div>
</body>
</html>