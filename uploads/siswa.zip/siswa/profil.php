<?php
session_start();
// Simulasi data siswa yang login
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = [
        'nama' => 'sarep bin joso',
        'kelas' => '11 IPA 2',
        'nisn' => '1234567890',
        'email' => 'sarep.joso@email.com',
        'no_hp' => '081234567890',
        'alamat' => 'Jl. Pendidikan No. 123, Surabaya',
        'tanggal_lahir' => '2007-03-15',
        'jenis_kelamin' => 'Laki-laki',
        'agama' => 'Islam',
        'nama_ayah' => 'Joso bin Karno',
        'nama_ibu' => 'Siti Aminah',
        'pekerjaan_ayah' => 'Wiraswasta',
        'pekerjaan_ibu' => 'Ibu Rumah Tangga'
    ];
}

$user = $_SESSION['user'];
$success_message = '';
$error_message = '';

if ($_POST) {
    // Update profil
    $updated_fields = ['email', 'no_hp', 'alamat'];
    foreach ($updated_fields as $field) {
        if (isset($_POST[$field])) {
            $_SESSION['user'][$field] = $_POST[$field];
        }
    }
    $success_message = "Profil berhasil diperbarui!";
    $user = $_SESSION['user']; // Refresh data
}

// Simulasi data prestasi
$prestasi = [
    ['nama' => 'Juara 1 Lomba Pidato Bahasa Indonesia', 'tahun' => '2024', 'tingkat' => 'Sekolah'],
    ['nama' => 'Juara 2 Olimpiade Matematika', 'tahun' => '2024', 'tingkat' => 'Kota'],
    ['nama' => 'Peserta Terbaik Leadership Camp', 'tahun' => '2023', 'tingkat' => 'Provinsi']
];

// Simulasi data organisasi
$organisasi = [
    ['nama' => 'Ketua Kelas 11 IPA 2', 'periode' => '2024-2025', 'status' => 'Aktif'],
    ['nama' => 'Anggota PMR', 'periode' => '2023-2024', 'status' => 'Tidak Aktif'],
    ['nama' => 'Tim Volly Sekolah', 'periode' => '2023-2025', 'status' => 'Aktif']
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIPOSIS - Profil</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 30px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .user-info {
            text-align: center;
            color: white;
            margin-bottom: 40px;
            padding: 0 20px;
        }

        .user-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }

        .user-name {
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .user-title {
            opacity: 0.8;
            font-size: 0.9rem;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 5px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: #fff;
        }

        .nav-icon {
            margin-right: 12px;
            font-size: 1.2rem;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;
        }

        .profile-container {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        .profile-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            height: fit-content;
        }

        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            position: relative;
        }

        .avatar-edit {
            position: absolute;
            bottom: 5px;
            right: 5px;
            width: 35px;
            height: 35px;
            background: #28a745;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            font-size: 0.8rem;
        }

        .profile-name {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .profile-class {
            color: #666;
            font-size: 1rem;
        }

        .info-section {
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #f1f3f4;
        }

        .info-grid {
            display: grid;
            gap: 15px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f8f9fa;
        }

        .info-label {
            font-weight: 600;
            color: #555;
            flex: 1;
        }

        .info-value {
            color: #333;
            flex: 2;
            text-align: right;
        }

        .edit-form {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        .form-title {
            font-size: 1.8rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-control:disabled {
            background: #f8f9fa;
            color: #6c757d;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            margin-right: 10px;
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .achievement-section {
            margin-top: 30px;
        }

        .achievement-grid {
            display: grid;
            gap: 15px;
        }

        .achievement-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #28a745;
        }

        .achievement-name {
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .achievement-details {
            color: #666;
            font-size: 0.9rem;
        }

        .organization-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #007bff;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .org-info {
            flex: 1;
        }